document.addEventListener('DOMContentLoaded', function () {
    const word = "COLOUR";
    const span = document.getElementById('colourSpan');
    let index = 0;

    function printLetterByLetter() {
        if (index < word.length) {
            span.textContent += word[index];
            index++;
            setTimeout(printLetterByLetter, 200); // Adjust the speed by changing the timeout value
        }
    }

    printLetterByLetter();
});



document.addEventListener('DOMContentLoaded', () => {
    const colorSelect = document.getElementById('color');
    const materialSelect = document.getElementById('material');
    const modelSelect = document.getElementById('model');
    const fabricPreview = document.getElementById('fabricPreview');

    const colorMap = {
        lilac: '#D8BFD8',
        'peach-pink': '#FFDAB9',
        'pista-green': '#9FBA9F',
        'powder-blue': '#B0E0E6'
    };

    function updatePreview() {
        const color = colorSelect.value;
        const material = materialSelect.value;
        const model = modelSelect.value;

        // Set the background color
        fabricPreview.style.backgroundColor = colorMap[color] || '#fff';

        // Set the preview text
        fabricPreview.textContent = `Model: ${model.charAt(0).toUpperCase() + model.slice(1)}\nMaterial: ${material.charAt(0).toUpperCase() + material.slice(1)}`;
    }

    colorSelect.addEventListener('change', updatePreview);
    materialSelect.addEventListener('change', updatePreview);
    modelSelect.addEventListener('change', updatePreview);
    submitBtn.addEventListener('click', handleSubmit);
    // Initialize the preview on page load
    updatePreview();
});
